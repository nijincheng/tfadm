import torch

device = torch.device('cuda:5' if torch.cuda.is_available() else 'cpu')
